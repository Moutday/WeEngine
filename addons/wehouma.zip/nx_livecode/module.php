<?php
/**
 * 活码系统
 *
 * @author Tim
 * @url http://wchat.q123.me
 */
defined('IN_IA') or exit('Access Denied');

class nx_livecodeModule extends WeModule {


}
